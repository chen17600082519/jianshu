import { createGlobalStyle } from 'styled-components';

export const GlobalStyle = createGlobalStyle`
	@font-face {font-family: "iconfont";
	  src: url('iconfont.eot?t=1544078510657'); 
	  src: url('iconfont.eot?t=1544078510657#iefix') format('embedded-opentype'), 
	  url('data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAAZwAAsAAAAACXQAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAADMAAABCsP6z7U9TLzIAAAE8AAAARAAAAFY8f0pDY21hcAAAAYAAAAB+AAAB3je6alpnbHlmAAACAAAAAkcAAAK8WbwD22hlYWQAAARIAAAALwAAADYTfQ9ZaGhlYQAABHgAAAAcAAAAJAfeA4hobXR4AAAElAAAAA4AAAAcHAAAAGxvY2EAAASkAAAAEAAAABACRALgbWF4cAAABLQAAAAfAAAAIAEVADxuYW1lAAAE1AAAAUUAAAJtPlT+fXBvc3QAAAYcAAAAUwAAAGii1OcpeJxjYGRgYOBikGPQYWB0cfMJYeBgYGGAAJAMY05meiJQDMoDyrGAaQ4gZoOIAgCKIwNPAHicY2BkYWCcwMDKwMHUyXSGgYGhH0IzvmYwYuRgYGBiYGVmwAoC0lxTGByecb4IZG7438AQw9zA0AAUZgTJAQDkDQw/eJztkUEKwkAMRV+ccVARV931CHXdexRceBxXHjX0FvVnIiiewQwv8D8TAvnAHijiKirYEyPqIde6Xzh1v3KTvnBgR/OjDz765PO6bBv86q8yzXwemq7ymjZrrzX+de79/lYtrpnoVviQRDo+JpGMT0n/PyeR5roklBclOiCnAAB4nDVSv2/TUBB+987Pbn6QpErsiJC4dUychoITktiukGgSqamQmFhQFCSQEFSiCNSK/gGRqkrd6YIYkDogxjCUjaqV2ilbp04MLAwszQBT4nJO6PN793TfO+u7++4YZ7T4D1xkcZZnDDS3Aa5VBkuOg6ylcRm85NRXMAaEefyTCOEiR2lTCvPbHMVbnMEB3RsixAdcAgNm+Da9dyhuifAOxY3/SFEJPhDiIQr/lbgmfoYVokbGLi/wCBPsBltgJcZCYJnFvKyAnApymdWh6nqzoFXdejFp5K26WzOqWko27+Ib/2s0jqGY7J9FND16AeqcCpCM6lrkzmiQUNUEOoGFHDyKgByE6WkID/3MBP3l/w5+gy/qvEqbZKBcekgfSzCDtFB0UGOgOEraIRnqpELgprS0Z0OAqHzUtSt4sNvrHY7Fymhim1OIf+/aW63dA2z2ek0xPnyyv/3/bl49TPiOqfYWUwM+Acvg2FCMBcRpqnpSNIEeuQTagN/8oVXCk729E0k62Wts2hAPZ1Kjfam/s9NHDKwCcXujMQ14f4q3LH8YTmXg705fuooKWi4R9yVxM6ZQ52+yMmOGWTQUE2pJtIomtVu4tWoOTMeUzbzl1BtQN/MKJaKmtFrVvQ/8aO2Bf95+CfHnK6+FzIWyDueV5XdLYLRsb/1p81752UJuPlOonJ0h80vQSFhm0j8W2a3TslspPY5FHxY6IntdzVYLOpvoTwMxh4KmQgkmwQGVDurjY94IDqxBt+1/bvsfV+EF+wfyDpOKAHicY2BkYGAAYo35nhfi+W2+MnCzMIDADb2n6xD0/wYWBuYGIJeDgQkkCgAyvwrTAHicY2BkYGBu+N/AEMPCAAJAkpEBFbADAEcNAnB4nGNhYGBgwYEBAdwAHQAAAAAAAABAAIYAvgD8AUYBXnicY2BkYGBgZzBgYGEAASYg5gJCBob/YD4DAA4TAVIAeJxlj01OwzAQhV/6B6QSqqhgh+QFYgEo/RGrblhUavdddN+mTpsqiSPHrdQDcB6OwAk4AtyAO/BIJ5s2lsffvHljTwDc4Acejt8t95E9XDI7cg0XuBeuU38QbpBfhJto41W4Rf1N2MczpsJtdGF5g9e4YvaEd2EPHXwI13CNT+E69S/hBvlbuIk7/Aq30PHqwj7mXle4jUcv9sdWL5xeqeVBxaHJIpM5v4KZXu+Sha3S6pxrW8QmU4OgX0lTnWlb3VPs10PnIhVZk6oJqzpJjMqt2erQBRvn8lGvF4kehCblWGP+tsYCjnEFhSUOjDFCGGSIyujoO1Vm9K+xQ8Jee1Y9zed0WxTU/3OFAQL0z1xTurLSeTpPgT1fG1J1dCtuy56UNJFezUkSskJe1rZUQuoBNmVXjhF6XNGJPyhnSP8ACVpuyAAAAHicbcjBDYAgDADAFlG0cRlHcJQSBOoDTLQxbi+JX+95YOBD8M+hwQ4t9jigwxHo3sQL10uWOXLJKkFK8mrPQwq1SYH3NmblKfCjUTNXgBc7FxN6AA==') format('woff'),
	  url('iconfont.ttf?t=1544078510657') format('truetype'),
	  url('iconfont.svg?t=1544078510657#iconfont') format('svg'); 
	}
	
	.iconfont {
	  font-family:"iconfont" !important;
	  font-size:16px;
	  font-style:normal;
	  -webkit-font-smoothing: antialiased;
	  -moz-osx-font-smoothing: grayscale;
	}
	
	.icon-weibiaoti1:before { content: "\e61b"; }
	
	.icon-fanhuidingbu:before { content: "\e609"; }
	
	.icon-spin:before { content: "\e851"; }
	
	.icon-fangdajing:before { content: "\e614"; }
	
	.icon-Aa:before { content: "\e636"; }
	
	.icon-dayufuhao:before { content: "\e62b"; }
	
	  html, body, div, span, applet, object, iframe,
	  h1, h2, h3, h4, h5, h6, p, blockquote, pre,
	  a, abbr, acronym, address, big, cite, code,
	  del, dfn, em, img, ins, kbd, q, s, samp,
	  small, strike, strong, sub, sup, tt,
	  var,
	  b, u, i, center,
	  dl, dt, dd, ol, ul, li,
	  fieldset, form, label, legend,
	  table, caption, tbody, tfoot, thead, tr, th, td,
	  article, aside, canvas, details, embed,
	  figure, figcaption, footer, header, hgroup,
	  menu, nav, output, ruby, section, summary,
	  time, mark, audio, video {
	  	margin: 0;
	  	padding: 0;
	  	border: 0;
	  	font - size: 100 % ;
	  	font: inherit;
	  	vertical - align: baseline;
	  }
	  article, aside, details, figcaption, figure,
	  footer, header, hgroup, menu, nav, section {
	  	display: block;
	  }
	  body {
	  	line - height: 1;
	  	font-family:-apple-system,SF UI Text,Arial,PingFang SC,Hiragino Sans GB,Microsoft YaHei,WenQuanYi Micro Hei,sans-serif;
	  }
	  ol, ul {
	  	list - style: none;
	  }
	  blockquote, q {
	  	quotes: none;
	  }
	  blockquote: before, blockquote: after,
	  	q: before, q: after {
	  		content: '';
	  		content: none;
	  	}
	  table {
	  	border - collapse: collapse;
	  	border - spacing: 0;
	  }
	  img{vertical-align:middle;}
	  .routerAnimation-enter{
		opacity: 0;
	    -webkit-transform: translate3d(0, 100px, 0);
	    transform: translate3d(0, 100px, 0);
	    transition:all 0.5s ease-out;
	  }
	  .routerAnimation-enter-active{
		opacity: 1;
	    -webkit-transform: none;
	    transform: none;
	  }
	  .routerAnimation-exit{
	  	opacity: 1;
	  	transition:all 0.5s ease-out;
	  }
	  .routerAnimation-exit-active{
			opacity: 0;
		    -webkit-transform: translate3d(0, 100px, 0);
		    transform: translate3d(0, 100px, 0);
		}
`;
