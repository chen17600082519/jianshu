import React, { PureComponent } from 'react';
import { RecommendWrapper, RecommendItem } from '../style';

const recommendList = [
	{
		id: 1,
		imgUrl:require('../../../statics/nav1.png')
	},
	{
		id: 2,
		imgUrl: require('../../../statics/nav2.png')
	},
	{
		id: 3,
		imgUrl: require('../../../statics/nav3.png')
	},
	{
		id: 4,
		imgUrl: require('../../../statics/nav4.png')
	},
	{
		id: 5,
		imgUrl: require('../../../statics/nav5.png')
	}
];
class Recommend extends PureComponent {
	render() {
		return(
			<RecommendWrapper>
				{
					recommendList.map((item)=>{
						return (
							<RecommendItem key={item.id} imgUrl={item.imgUrl} />
						)
					})
				}
			</RecommendWrapper>
		)
	}
}


export default Recommend;