import React,{ PureComponent,Fragment} from 'react';
import { CSSTransition } from 'react-transition-group';
import { connect } from 'react-redux';
import { EwmCodeWrapper, EwmCodeInfo, EwmAlert } from '../style';
import { actionCreators } from '../store';

class EwmCode extends PureComponent {
	render(){
		const { hovered, handleMouseEnter, handleMouseLeave } = this.props;
		
		return (
			<EwmCodeWrapper onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
				<img className="codeImg" alt="二维码" src={require("../../../statics/code.png")} />
				<EwmCodeInfo>
					<h3>下载简书手机App<i className="iconfont">&#xe62b;</i></h3>
					<p>随时随地发现和创作内容</p>
				</EwmCodeInfo>
				<CSSTransition in={hovered} timeout={300} classNames="fade">
					<Fragment>
						{this.getCode(hovered)}
					</Fragment>
				</CSSTransition>
			</EwmCodeWrapper>
		)
	}
	getCode(hovered){
		if(hovered){
			return (
				<EwmAlert className="ewmAlert">
					<img className="EwmAlertImg" alt="二维码" src={require("../../../statics/code.png")} />
					<b className="xiaojiao"></b>
				</EwmAlert>
			)
		}else{
			return null;
		}
	}
}

const mapState = (state)=>({
	hovered:state.getIn(['home','hovered'])
});
const mapDispatch = (dispatch)=>{
	return {
		handleMouseEnter(){
			const action = actionCreators.getMouseEnter;
			dispatch(action);
		},
		handleMouseLeave(){
			const action=actionCreators.getMouseLeave;
			dispatch(action);
		}
	}
}
export default connect(mapState,mapDispatch)(EwmCode);