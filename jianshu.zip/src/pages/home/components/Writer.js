import React,{ PureComponent } from 'react';
import { connect } from 'react-redux';
import { WriterWrapper, WriterTitle, WriterSwitch, WriterList, WriterListItem, LookAll } from '../style';
import { actionCreators } from '../store';
class Writer extends PureComponent {
	render(){
		const { writerList, writerPage, writerTotalPage, handleChangePage }=this.props;
		const newList=writerList.toJS();
		const list=[];
		if(newList.length){
			let len;
			if(writerPage===writerTotalPage){
				len=newList.length;
			}else{
				len=writerPage*5;
			}
			for(let i=(writerPage-1)*5;i<len;i++){
				list.push(
					<WriterListItem key={newList[i].id}>
						<img className="pic" src={newList[i].imgUrl} alt={newList[i].name}/>
						<a className="care" href="/">+关注</a>
						<a className="writerName" href="/">{newList[i].name}</a>
						<p className="desc">{newList[i].desc}</p>
					</WriterListItem>
				);
			}
		}
		return (
			<WriterWrapper>
				<WriterTitle>
					推荐作者
					<WriterSwitch onClick={()=>{handleChangePage(writerPage,writerTotalPage,this.spinIcon)}}>
						<i ref={(icon)=>{this.spinIcon=icon}} className="iconfont spin">&#xe851;</i>换一批		
					</WriterSwitch>
				</WriterTitle>
				<WriterList>
					{list}
				</WriterList>
				<LookAll>查看全部></LookAll>
			</WriterWrapper>
		)
	}
	componentWillMount(){
		this.props.initWriterList();
	}
}
const mapStateToProps = (state)=>{
	return {
		writerList:state.getIn(['home','writerList']),
		writerPage:state.getIn(['home','writerPage']),
		writerTotalPage:state.getIn(['home','writerTotalPage'])
	}
}
const mapDispatchToProps = (dispatch)=>{
	return {
		handleChangePage(writerPage, writerTotalPage, spinIcon){
			let originAngle=spinIcon.style.transform.replace(/[^0-9]/ig,'');
			if(originAngle){
				originAngle=parseInt(originAngle,10);
			}else{
				originAngle=0;
			}
			spinIcon.style.transform='rotate('+(originAngle+360)+'deg)';
			if(writerPage<writerTotalPage){
				dispatch(actionCreators.changeWriterPage(writerPage+1));
			}else{
				dispatch(actionCreators.changeWriterPage(1));
			}
		},
		initWriterList(){
			dispatch(actionCreators.getWriterList());
		}
	}
}
export default connect(mapStateToProps,mapDispatchToProps)(Writer);