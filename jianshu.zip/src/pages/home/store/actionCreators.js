import axios from 'axios';
import * as actionTypes from './actionTypes';
import { fromJS } from 'immutable';

const changeHomeData = (result)=>({
	type:actionTypes.CHANGE_HOME_DATA,
	topicList:result.topicList,
	articleList:result.articleList,
	recommendList:result.recommendList
});
const AddHomeList = (result,nextPage)=>({
	type:actionTypes.ADD_HOME_LIST,
	articleList:fromJS(result.articleList),
	nextPage
});

const changeWriterList = (data)=>({
	type:actionTypes.CHANGE_WRITER_LIST,
	data:fromJS(data),
	writerTotalPage:Math.ceil(data.length/5)
});


export const getHomeInfo = ()=>{
	return (dispatch) => {
		axios.get('/api/home.json').then((res)=>{
			const result = res.data.data;
			dispatch(changeHomeData(result));
		});
	}
};

export const getMouseEnter = {
	type:actionTypes.MOUSE_ENTER
};

export const getMouseLeave = {
	type:actionTypes.MOUSE_LEAVE
};

export const getMoreList = (page)=>{
	return (dispatch)=>{
		axios.get('/api/articleList.json?page='+page).then((res)=>{
			const result = res.data.data;
			dispatch(AddHomeList(result,page+1));
		});
	}
};

export const changeWriterPage = (writerPage)=>({
	type:actionTypes.CHANGE_WRITERPAGE,
	writerPage
});
export const getWriterList = ()=>{
	return (dispatch) => {
		axios.get('/api/writer.json').then((res)=>{
			const result = res.data.data.writerList;
			dispatch(changeWriterList(result));
		});
	}
};
export const toggleTopShow= (show)=>({
	type:actionTypes.TOGGLE_SCROLL_SHOW,
	show
});