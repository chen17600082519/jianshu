export const MOUSE_LEAVE = 'home/MOUSE_LEAVE';
export const MOUSE_ENTER = 'home/MOUSE_ENTER';
export const CHANGE_HOME_DATA = 'home/CHANGE_HOME_DATA';
export const ADD_HOME_LIST = 'home/ADD_HOME_LIST';
export const CHANGE_WRITERPAGE = 'home/CHANGE_WRITERPAGE';
export const CHANGE_WRITER_LIST = 'home/CHANGE_WRITER_LIST';
export const TOGGLE_SCROLL_SHOW = 'home/TOGGLE_SCROLL_SHOW';
