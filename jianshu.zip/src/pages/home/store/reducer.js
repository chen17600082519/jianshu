import { fromJS } from 'immutable';
import * as actionTypes from './actionTypes';

const defaultState=fromJS({
	topicList:[],
	articleList:[],
	recommendList:[],
	hovered:false,
	articlePage:1,
	writerList:[],
	writerPage:1,
	writerTotalPage:1,
	showScroll:false
});
export default (state = defaultState, action) => {
	switch(action.type){
		case actionTypes.MOUSE_ENTER:
			return state.set('hovered',true);
		case actionTypes.MOUSE_LEAVE:
			return state.set('hovered',false);
		case actionTypes.CHANGE_HOME_DATA:
			return state.merge({
				topicList:fromJS(action.topicList),
				articleList:fromJS(action.articleList),
				recommendList:fromJS(action.recommendList)
			});
		case actionTypes.ADD_HOME_LIST:
			return state.merge({
				articleList:state.get('articleList').concat(action.articleList),
				articlePage:action.nextPage
			});
		case actionTypes.CHANGE_WRITERPAGE:
			return state.set('writerPage',action.writerPage);
		case actionTypes.CHANGE_WRITER_LIST:
			return state.merge({//修改多个值
				writerList:action.data,
				writerTotalPage:action.writerTotalPage
			});
		case actionTypes.TOGGLE_SCROLL_SHOW:
			return state.set('showScroll',action.show)
		default:
			return state;
	}

}