import React,{ PureComponent } from 'react';
import Topic from './components/Topic';
import List from './components/List';
import Recommend from './components/Recommend';
import EwmCode from './components/EwmCode'; 
import Writer from './components/Writer';
import { HomeWrapper, HomeLeft, HomeRight, BackTop } from './style';
import { connect } from 'react-redux';
import { actionCreators } from './store';
class Home extends PureComponent {
	handleScrollTop(){
		var timer=setInterval(function(){
           var scrollTop=document.documentElement.scrollTop||document.body.scrollTop;
           var ispeed=Math.floor(-scrollTop/4);
           if(scrollTop===0){
               clearInterval(timer);
           }
           document.documentElement.scrollTop=document.body.scrollTop=scrollTop+ispeed;
       },30)
	}
	render(){
		return (
			<HomeWrapper>
				<HomeLeft>
					<img className="banner-img" alt="banner" src={require('../../statics/banner1.jpg')} />
					<Topic />
					<List />
				</HomeLeft>
				<HomeRight>
					<Recommend />
					<EwmCode/>
					<Writer />
				</HomeRight>
				{ this.props.showScroll ? <BackTop onClick={this.handleScrollTop}><i className="iconfont">&#xe609;</i></BackTop> : null}
				
			</HomeWrapper>
		)
	}

	componentDidMount(){
		this.props.changeHomeData();
		this.bindEvents();
	}
	componentWillUnmount(){
		window.removeEventListener('scroll',this.props.chageScrollTopShow)
	}
	bindEvents(){
		window.addEventListener('scroll',this.props.chageScrollTopShow)
	}
	
}

const mapState = (state)=>({
	showScroll:state.getIn(['home','showScroll'])
})
const mapDispatch = (dispatch)=>({
	changeHomeData(){
		dispatch(actionCreators.getHomeInfo());
	},
	chageScrollTopShow(){
		var scrollTop=document.documentElement.scrollTop||document.body.scrollTop;
		if(scrollTop>100){
			dispatch(actionCreators.toggleTopShow(true));
		}else{
			dispatch(actionCreators.toggleTopShow(false));
		}
	}
});

export default connect(mapState,mapDispatch)(Home);