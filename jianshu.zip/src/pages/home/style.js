import styled from 'styled-components';

export const HomeWrapper=styled.div`
	width:960px;
	overflow:hidden;
	margin:0 auto;
`;

export const HomeLeft=styled.div`
	float:left;
	margin-left:15px;
	padding-top:30px;
	width:625px;
	.banner-img{
		width:625px;
		height:270px;
	}
`;

export const HomeRight=styled.div`
	width:280px;
	float:right;
`;
export const TopicWrapper=styled.div`
	padding:20px 0 10px 0;
	margin-left:-18px;
	overflow:hidden;
	border-bottom:1px solid #dcdcdc;
`;
export const TopicItem=styled.div`
	float:left;
	background:#f7f7f7;
	height:32px;
	line-height:32px;
	font-size:14px;
	border:1px solid #dcdcdc;
	border-radius:2px;
	padding-right:10px;
	margin-left:18px;
	.topic-pic{
		height:32px;width:32px;
		display:block;float:left;
		margin-right:10px;
	}
`;
export const ListItem=styled.div`
	padding:20px 0;
	overflow:hidden;
	border-bottom:1px solid #dcdcdc;
	.pic{
		width:123px;height:100px;
		display:block;float:right;
		border-radius:4px;border:1px solid #dcdcdc;
	}
`;
export const ListInfo=styled.div`
	width:500px;float:left;
	.title{
		font-size:18px;line-height:27px;
		font-weight:bold;color:#333;
		cursor:pointer;
		&:hover{
			text-decoration:underline;
		}
	}
	.desc{
		font-size:13px;line-height:24px;
		color:#999;
	}
`;
export const RecommendWrapper=styled.div`
	margin:30px 0;
	width:280px;
`;
export const RecommendItem=styled.div`
	width:280px;height:50px;margin-bottom:5px;
	background:url(${(props)=>props.imgUrl});
	background-size:contain;
	cursor:pointer;
`;
export const EwmCodeWrapper=styled.div`
	padding:10px 22px;
	border:1px solid #dcdcdc;
	border-radius:5px;
	&:after{
		content:'';
		display:block;
		clear:both;
	}
	cursor:pointer;
	margin-bottom:30px;
	position:relative;
	.codeImg{
		float:left;
		width:60px;height:60px;
	}
`;
export const EwmCodeInfo=styled.div`
	float:left;
	display:inline-blcok;
	vertical-align:middle;
	margin-left:7px;
	margin-top:8px;
	h3{
		font-size: 15px;
        color: #333;
        .iconfont{
        	font-size:12px;
        	font-weight:bold;
        	margin-left:10px;
        }
	}
	p{
		margin-top: 4px;
	    font-size: 13px;
	    color: #999;
	}
`;
export const EwmAlert=styled.div`
	position:absolute;left:50%;margin-left:-90px;top:-195px;
	box-sizing:border-box;box-shadow:0 5px 10px 0 #ddd;
	padding:10px;background:#fff;border-radius:5px;
	border:1px solid #dcdcdc;
	.EwmAlertImg{
		width:160px;height:160px;
	}
	.xiaojiao{
		width:16px;height:16px;
		position:absolute;
		left:50%;margin-left:-8px;
		bottom:-8px;
		box-sizing:border-box;
		background:#fff;
		border-right:1px solid #ddd;
		border-bottom:1px solid #ddd;
		transform:rotate(45deg);
	}
	&.fade-enter{
		opacity:0;
		transition:all 0.3s ease-out;
	}
	&.fade-enter-active{
		opacity:1;
	}
	&.fade-exit{
		opacity:1;
		transition:all 0.3s ease-out;
	}
	&.fade-exit-active{
		opacity:0;
	}
`;
export const WriterWrapper=styled.div`
	width:278px;
`;
export const LoadMore=styled.div`
	width:100%;
	height:40px;
	line-height:40px;
	margin:30px 0;
	background:#a5a5a5;
	text-align:center;
	border-radius:20px;
	color:#fff;
	cursor:pointer;
`;
export const BackTop=styled.div`
	position:fixed;
	right:30px;;bottom:30px;
	width:50px;
	height:50px;
	line-height:50px;
	text-align:center;
	border:1px solid #ccc;
	cursor:pointer;
	background:rgba(255,255,255,1);
	transition:all 0.1s;
	&:hover{
		background:rgba(200,200,200,0.1);
	}
	.iconfont{
		font-size:22px;
		color:#aaa;
	}
`;
export const WriterTitle = styled.div`
	margin-top:20px;
	margin-bottom:15px;
	line-height:20px;
	font-size:14px;
	color:#969696;
`;
export const WriterSwitch = styled.div`
	float:right;
	font-size:14px;
	cursor:pointer;
	.spin{
		display:block;
		float:left;
		font-size:14px;
		margin-right:2px;
		transition:all .3s ease-in;
	}
`;
export const WriterList = styled.div`
	margin-bottom:20px;
`;
export const WriterListItem = styled.div`
	margin-top:15px;line-height:20px;
	.pic{
		width:48px;height:48px;
		float:left;margin-right:10px;
		border-radius:24px;cursor:pointer;
	}
	.writerName{
	    padding-top: 5px;
	    margin-right: 60px;
	    font-size: 14px;
	    display: block;
	    color:#333;
	    cursor:pointer;
	}
	.care{
		float: right;
	    margin-top: 5px;
	    font-size: 13px;
	    color: #42c02e;
	    cursor:pointer;
	}
	.desc{
	    margin-top: 2px;
	    font-size: 12px;
	    color: #969696;
	}
`;

export const LookAll = styled.div`
	background:#f7f7f7;
	border:1px solid #dcdcdc;
    border-radius: 4px;
    text-align:center;
    cursor:pointer;
    font-size:13px;
    color:#787878;
    padding:8px 0;
`;
