export const CHANGE_LOGIN = "login/CHANGE_LOGIN";
export const CHANGE_LOGOUT = "login/CHANGE_LOGOUT";