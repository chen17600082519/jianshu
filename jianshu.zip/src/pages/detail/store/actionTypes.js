export const CHANGE_DETAIL = "detail/CHANGE_DETAIL";
