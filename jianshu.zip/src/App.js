import React, { Component,Fragment } from 'react';
import { Provider } from 'react-redux';
import { GlobalStyle } from './style';
import { BrowserRouter, Route } from 'react-router-dom';
import { CSSTransition } from 'react-transition-group';
import Header from './common/header';
import Home from './pages/home';
import Detail from './pages/detail';
import Login from './pages/login';
import Write from './pages/write';
import store from './store';

//高阶组件
function wrapAnimation(WrappedComponent) {
  return class extends Component {
    render() {
      return (
        <CSSTransition
          in={this.props.match !== null}
          classNames="routerAnimation"
          timeout={1000}
          mountOnEnter={true}
          unmountOnExit={true}
        >
          <WrappedComponent {...this.props} />
        </CSSTransition>
      )
    }
  }
}
const HomeG = wrapAnimation(Home);
const LoginG = wrapAnimation(Login);
const DetailG = wrapAnimation(Detail);
const WriteG = wrapAnimation(Write);


class App extends Component{
	render(){
		return (
			<Fragment>
				<GlobalStyle />
				<Provider store={store}>
					<Fragment>
						<BrowserRouter>
							<Fragment>
								<Header />
								<Route path='/' exact children={props => {return <HomeG {...props} /> }} />
								<Route path='/login' exact children={props => {return <LoginG {...props} /> }} />
								<Route path='/detail/:id' exact children={props => {return <DetailG {...props} /> }} />
								<Route path='/write' exact children={props => {return <WriteG {...props} /> }} />
							</Fragment>
						</BrowserRouter>
					</Fragment>
				</Provider>
			</Fragment>
		)
	}
}


export default App;
